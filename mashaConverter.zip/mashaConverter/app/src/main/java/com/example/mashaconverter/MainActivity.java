package com.example.mashaconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    Double ru;
    Double eu;
    public void onClick(View v) {
        EditText editText = (EditText) findViewById(R.id.editTextTextMultiLine);
        ru = Double.parseDouble(editText.getText().toString());
        eu = ru - 6;
        TextView textView = (TextView) findViewById(R.id.textView);
        textView.setText("Ж: " + eu.toString() + "  " + "М: " + ru.toString());
    }
}